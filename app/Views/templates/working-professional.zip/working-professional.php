  <?php include('header.php'); ?>

   <div class="top1">
      <div class="top-menu">
        <div class="top-menu-logos">
            <a href="/" class="step-bg-white">
                <img src="assets/images/STEP.svg" alt="STEP">
            </a>
            <a href="/" class="step-bg-black">
                <img src="assets/images/STEP-logo-bg-black.png" alt="STEP">
            </a>
            <img src="assets/images/hindu-newspaper-bg-white.png" alt="The Hindu" class="step-bg-black" />
            <img src="assets/images/hindu-newspaper.svg" alt="The Hindu" class="step-bg-white" />
        </div>
        <div class="top-menu-items">
            <div class="dropdown">
                <button class="dropbtn">
                    <?php
                    $countryCode = session()->get('countryCode');
                    $flagImage = ($countryCode === 'IN') ? 'in' : 'worldwide';
                    $flagAlt = ($countryCode === 'IN') ? 'IN Flag' : 'INT Flag';
                    ?>
                    <img src="https://storage.googleapis.com/assets.thehindustep.in/flags/<?= $flagImage ?>.svg" alt="<?= $flagAlt ?>" />
                    <p><?= $countryCode === 'IN' ? 'IN' : 'INT' ?></p>
                    <span class="flagindia">&#9662;</span>
                </button>
               <div class="dropdown-content">
                        <a  href="/stepwebsite/india/"  onclick="selectFlag('IN', 'https://storage.googleapis.com/assets.thehindustep.in/flags/in.svg')" data-country-code="IN">
                            <img src="https://storage.googleapis.com/assets.thehindustep.in/flags/in.svg" alt="IN Flag" />
                            India
                        </a>
                        <a href="/stepwebsite/international/"  onclick="selectFlag('INT', 'https://storage.googleapis.com/assets.thehindustep.in/flags/worldwide.svg')" data-country-code="INT">
                            <img src="https://storage.googleapis.com/assets.thehindustep.in/flags/worldwide.svg" alt="INT Flag" />
                            
                            International
                       </a>
                    </div>
            </div>
            <a href="/" title="For Corporate">For Corporate</a>
            <a href="/" title="For Institutions">For Institutions</a>
            <a href="https://english.steptest.in/signup" title="Login" class="highlight">Login</a>
        </div>

        </div>
    </div> 

   <div id="myModal" class="modal">
    <div class="buynowpage">
        <div id="formWrapper">

            <div id="form">
                <span id="close" onClick="refreshPage()" onclick="this.parentNode.parentNode.remove (); return false;">&times</span>
                <div class="pricedetails">
                    <div class="top-menu-logos">
                        <a href="/" class="step-bg-white">
                            <img src="assets/images/STEP.svg" alt="STEP"></a>
                            <img src="assets/images/hindu-newspaper.svg" alt="The Hindu" class="step-bg-white" />
                        </div>
                        <h2 class="heading" id="data-title"></h2>
                        <div class="originalPrice" id ="data-originalprice"></div>
                        <div class="offerPrice" id="data-offerprice"></div>
                        <div class="savedOffer" id="saved-price"></div>
                    </div>
                    <div class="form-item">
                      <p class="formLabel">Email/Phone no</p>
                        <input type="email" name="email" id="p-email" class="form-style" autocomplete="off"/> 
                         <input type="hidden" name="txtProductId" id="data-product-id">
                         <input type="hidden" name="countryCode" id="country-code">
                    </div>
                    <div class="form-item">
                        
             <p class="formLabel">Coupon code</p>
            <input type="text" name="txtCoupon" id="txtCoupon" class="form-style coupon"/>
            <button type="button" class="login pull-right  couponbtn" id="txtCoupon">Apply</button> 
        </div>
        <div class="form-item1">
            <input type="submit" class="login c-button" value="Buy Now"/> 
        </div>
</div>
</div>
</div>
</div>

      <div class="product-plans-page">
        <div class="ppp-top-section">
          <div class="ppp-top-section-bg">
            <div class="course-type-box-highlight course-type-box-gencom"></div>
          </div>
          <h3 class="ppp-subtitle">English for</h3>
          <h1 class="ppp-title">Working Professionals</h1>
          <p class="ppp-description">Courses focus on English language skills for <span class="orangeHigh">workplace communication</span>.</p>
          <p class="ppp-description-2">These courses not only tackle the listening, reading and writing, grammar, vocabulary and speaking skills needed for effective communication at the workplace, but they also aim to develop allied workplace skills such as presentation skills, skills for business meetings etc.</p>
        </div>
        


         <div class="title-tab-contents">
         
             <?php $commonValuesSet = false; ?>
             <?php foreach ($CourseDetails as $index => $course) { ?>
                <?php if ($course['product_id'] != 607 ): ?>
                 <?php if (!$commonValuesSet) { ?>
                     <div class="title-tab-main title-tab-main-label pad-rgt">
                         <div class="title-tab-header align-flx-end">             
                         </div>
                         <div class="title-tab-row">
                             Coach calls <span class="popover-element" data-toggle="popover" data-content="<?= $course['coach_calls'] ?>">i</span>
                         </div>
                         <div class="title-tab-row">
                             Live calls <span class="popover-element" data-toggle="popover" data-content="<?= $course['live_calls'] ?>">i</span>
                         </div>
                         <div class="title-tab-row">
                             Online calls <span class="popover-element" data-toggle="popover" data-content="<?= $course['online_classes'] ?>">i</span>
                         </div>
                         <div class="title-tab-row">
                             Validity (months) <span class="popover-element popover-hidden" data-text="">i</span>
                         </div>
                         <div class="title-tab-row">
                             Original price <span class="popover-element popover-hidden" data-text="">i</span>
                         </div>
                         <div class="title-tab-row">
                             Offer price <span class="popover-element popover-hidden" data-text="">i</span>
                         </div>
                         <div class="title-tab-row">
                             Available on web and app
                         </div>
                         <div class="title-tab-row">
                             Why you should buy this course 
                         </div>
                         <?php $commonValuesSet = true; ?>
                     </div>
                 <?php } ?>

                 <?php
                   $productLinks = ['generalcommunicationonline', 'generalcommunicationcrash', 'generalcommunicationunlimited'];
                   ?>


                 <div class="title-tab-main-texts">
                     <div class="title-tab-main" data-target="workingProfessional" data-id="title-tab-main-texts-<?= $index ?>" id="title-tab-main-texts-<?= $index ?>">
                         <div class="title-tab-main-flex-1">
                             <?php if ($index === 2) {  ?>
                                <div class="bestsell">
                             <span class="bestSeller">Best seller</span>
                             </div>
                             <?php } ?>
                             <div class="title-tab-header"> 
                                 <span class="title-tab-result-header"><?= $course['product_name'] ?></span>
                                 <div class="cellOfferPrice">
                                     <?php if ($countryCode === 'IN') { ?>
                                         ₹<?= $course['offer_price'] ?> 
                                     <?php } else { ?>
                                         $<?= $course['offer_price_usd'] ?> 
                                     <?php } ?>
                                 </div>
                                 <div class="strikeOriginalPrice">
                                     <?php if ($countryCode === 'IN') { ?>
                                         ₹<?= $course['original_price'] ?> 
                                     <?php } else { ?>
                                         $<?= $course['original_price_usd'] ?> 
                                     <?php } ?>
                                 </div>

                             </div>
                             <div class="title-tab-row"><?= $course['coach_calls'] ?></div>
                             <div class="title-tab-row"><?= $course['live_calls'] ?></div>
                             <div class="title-tab-row"><?= $course['online_classes'] ?></div>
                             <div class="title-tab-row title-tab-row-months">
                                 <a href="javascript:void(0)" class="border-btn active"
                                    data-validity="<?= $course['licence_expiry_days'] ?>"
                                    data-OriginalPrice="<?= $course['original_price'] ?>"
                                    data-OfferPrice="<?= $course['offer_price'] ?>"><?= $course['licence_expiry_days'] ?></a>
                             </div>
                           
                             <div class="title-tab-row strikeOriginalPrice">
                                   <?php if ($countryCode === 'IN') { ?>
                                       ₹<?= $course['original_price'] ?> 
                                   <?php } else { ?>
                                       $<?= $course['original_price_usd'] ?> 
                                   <?php } ?> 
                                </div>
                             <div class="title-tab-row cellOfferPrice">
                                <?php if ($countryCode === 'IN') { ?>
                                        ₹<?= $course['offer_price'] ?> 
                                    <?php } else { ?>
                                        $<?= $course['offer_price_usd'] ?> 
                                    <?php } ?>    
                                </div>

                             <div class="title-tab-row webAndAppIcons">
                                 <a href="https://english.steptest.in/" class="webAnchorLink" title="Login to STEP" target="_blank">
                                     <img src="assets/images/chrome.png" alt="Web" />
                                 </a>
                                 <a href="https://  play.google.com/store/apps/details?id=com.hindu.step" title="STEP Android App" target="_blank">
                                     <img src="assets/images/play-store-step-app.png" alt="Android App" />
                                 </a>
                             </div>
                             <div class="title-tab-row title-tab-row-content">
                                 <p class="title-tab-row-content-para"><?= $course['product_meta_desc'] ?></p>
                                 <a href="<?= $productLinks[$index] ?>" target="_blank" title="Click for more details" class="default-anchor">Click here to see topics</a>
                             </div>
                             <div class="title-tab-footer">
                                <?php
                                    if ($countryCode === 'IN') {
                                        $savedPrice = $course['original_price'] - $course['offer_price'];
                                        $savedPrice = '₹' . number_format($savedPrice, 2);
                                    } else {
                                        $savedPrice = $course['original_price_usd'] - $course['offer_price_usd'];
                                        $savedPrice = '$' . number_format($savedPrice, 2);
                                    }
                                    ?>
                                <button class="btn-default open-modal" country-code = "<?=  $countryCode === 'IN' ?  'IN' :  'INT'?>" data-title="<?= $course['product_name'] ?>"  data-price="<?= $countryCode === 'IN' ? '₹' .$course['original_price'] : '$' . $course['original_price_usd'] ?>"  data-offerprice="<?= $countryCode === 'IN' ? '₹' .$course['offer_price'] : '$' . $course['offer_price_usd'] ?>"   saved-price=" <?= $savedPrice ?>" data-product-id="<?= $course['product_id']?>" >BUY</button>
                             </div>

                         </div>
                     </div>
                 </div>
              <?php endif; ?>
             <?php } ?>
         </div>
 <div class="ppp-top-section ppp-footer-section">
    <h3 class="ppp-subtitle">Explore</h3>
     <div class="category-card-container">

        <?php foreach ($productData as $index => $product): ?>
            <?php if ($product['product_name_slug'] != 'stepforworkingprofessionals' ): ?>
                <div class="category-card category-card-item-<?= $index ?>">
                    <div class="category-card-inner" onclick="gotoURL('<?= $product['product_name_slug'] ?>')">
                        <h1><?= $product['product_name'] ?></h1>
                        <span>Starting from</span>
                        <div class="price-div" countryCode="<?= $countryCode === 'IN' ? 'IN' : 'INT' ?>">
                            <?php if ($countryCode === 'IN'): ?>
                                ₹<?= $product['offer_price'] ?>
                            <?php else: ?>
                                $<?= $product['offer_price_usd'] ?> 
                            <?php endif; ?>
                            <a href="<?= $product['product_name_slug'] ?>" class="learn-more">Learn more</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>

    </div>
</div>
</div>
      


 <?php include('footer.php'); ?>

